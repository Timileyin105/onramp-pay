(function (blocks, i18n, element, components, editor) {
      const { registerPaymentMethod } = wc.wcBlocksRegistry;
      // Use the localized data from PHP
      const onramppaygateways = onramppaygatewayData || [];
      onramppaygateways.forEach((onramppaygateway) => {
            registerPaymentMethod({
                  name: onramppaygateway.id,
                  label: onramppaygateway.label,
                  ariaLabel: onramppaygateway.label,
                  content: element.createElement(
                        'div',
                        { className: 'onramppaygateway-method-wrapper' },
                        element.createElement(
                              'div',
                              { className: 'onramppaygateway-method-label' },
                              '' + onramppaygateway.description
                        ),
                        onramppaygateway.icon_url ? element.createElement(
                              'img',
                              {
                                    src: onramppaygateway.icon_url,
                                    alt: onramppaygateway.label,
                                    className: 'onramppaygateway-method-icon'
                              }
                        ) : null
                  ),
                  edit: element.createElement(
                        'div',
                        { className: 'onramppaygateway-method-wrapper' },
                        element.createElement(
                              'div',
                              { className: 'onramppaygateway-method-label' },
                              '' + onramppaygateway.description
                        ),
                        onramppaygateway.icon_url ? element.createElement(
                              'img',
                              {
                                    src: onramppaygateway.icon_url,
                                    alt: onramppaygateway.label,
                                    className: 'onramppaygateway-method-icon'
                              }
                        ) : null
                  ),
                  canMakePayment: () => true,
            });
      });
})(
      window.wp.blocks,
      window.wp.i18n,
      window.wp.element,
      window.wp.components,
      window.wp.blockEditor
);