<?php

/**
 * Plugin Name: Onramp Pay
 * Plugin URI: https://onramp-pay.com
 * Description: Instant Approval High Risk Merchant Gateway with instant payouts to your USDC wallet.
 * Version: 1.3.1
 * Requires Plugins: woocommerce
 * Requires at least: 5.8
 * Tested up to: 6.9
 * WC requires at least: 5.8
 * WC tested up to: 10.3.6
 * Requires PHP: 7.2
 * Author: onramp-pay.com
 * Author URI: https://onramp-pay.com/
 * License: GPLv3
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
      exit;
}

add_action('before_woocommerce_init', function () {
      if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
      }
});

add_action('before_woocommerce_init', function () {
      if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
      }
});

/**
 * Enqueue block assets for the gateway.
 */
function onramppaygateway_enqueue_block_assets()
{
      // Fetch all enabled WooCommerce payment gateways
      $onramppaygateway_available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
      $onramppaygateway_gateways_data = array();

      foreach ($onramppaygateway_available_gateways as $gateway_id => $gateway) {
            if (strpos($gateway_id, 'onramppay-instant-payment-gateway') === 0) {
                  $icon_url = method_exists($gateway, 'onramppay_instant_payment_gateway_get_icon_url') ? $gateway->onramppay_instant_payment_gateway_get_icon_url() : '';
                  $onramppaygateway_gateways_data[] = array(
                        'id' => sanitize_key($gateway_id),
                        'label' => sanitize_text_field($gateway->get_title()),
                        'description' => wp_kses_post($gateway->get_description()),
                        'icon_url' => sanitize_url($icon_url),
                  );
            }
      }

      wp_enqueue_script(
            'onramppaygateway-block-support',
            plugin_dir_url(__FILE__) . 'assets/js/onramppaygateway-block-checkout-support.js',
            array('wc-blocks-registry', 'wp-element', 'wp-i18n', 'wp-components', 'wp-blocks', 'wp-editor'),
            filemtime(plugin_dir_path(__FILE__) . 'assets/js/onramppaygateway-block-checkout-support.js'),
            true
      );

      // Localize script with gateway data
      wp_localize_script(
            'onramppaygateway-block-support',
            'onramppaygatewayData',
            $onramppaygateway_gateways_data
      );
}
add_action('enqueue_block_assets', 'onramppaygateway_enqueue_block_assets');

/**
 * Enqueue styles for the gateway on checkout page.
 */
function onramppaygateway_enqueue_styles()
{
      if (is_checkout()) {
            wp_enqueue_style(
                  'onramppaygateway-styles',
                  plugin_dir_url(__FILE__) . 'assets/css/onramppaygateway-payment-gateway-styles.css',
                  array(),
                  filemtime(plugin_dir_path(__FILE__) . 'assets/css/onramppaygateway-payment-gateway-styles.css')
            );
      }
}
add_action('wp_enqueue_scripts', 'onramppaygateway_enqueue_styles');

include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-hostedonramppay.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-revolut.php'); // Include the payment gateway class	
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-stripe.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-rampnetwork.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-transak.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-moonpay.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-banxa.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-guardarian.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-utorg.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-transfi.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-sardine.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-kryptonim.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-topper.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-cryptix.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-unlimit.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-bitnovo.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-robinhood.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-upi.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-interac.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-simplex.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-binance.php'); // Include the payment gateway class
include_once(plugin_dir_path(__FILE__) . 'includes/class-onramppay-instant-payment-gateway-customprovider.php'); // Include the payment gateway class

// Conditional function that check if Checkout page use Checkout Blocks
function onramppaygateway_is_checkout_block()
{
      return WC_Blocks_Utils::has_block_in_page(wc_get_page_id('checkout'), 'woocommerce/checkout');
}

function onramppaygateway_add_notice($onramppaygateway_message, $onramppaygateway_notice_type = 'error')
{
      // Check if the Checkout page is using Checkout Blocks
      if (onramppaygateway_is_checkout_block()) {
            // For blocks, throw a WooCommerce exception
            if ($onramppaygateway_notice_type === 'error') {
                  throw new \WC_Data_Exception('checkout_error', esc_html($onramppaygateway_message));
            }
            // Handle other notice types if needed
      } else {
            // Default WooCommerce behavior
            wc_add_notice(esc_html($onramppaygateway_message), $onramppaygateway_notice_type);
      }
}
