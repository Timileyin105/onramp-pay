=== Onramp Pay Crypto Payment Gateway ===
Contributors: onramp-pay.com
Donate link: https://onramp-pay.com
Tags: cryptocurrency, payments, woocommerce, checkout, crypto
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.1.4
Requires PHP: 7.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
Crypto Payment Gateway adds a set of WooCommerce payment methods that let customers pay with multiple cryptocurrencies and stablecoins. Payouts go directly to your wallet, no custodians or KYC. Works with classic checkout and block-based checkout.

== Installation ==
1. Upload the plugin to your `/wp-content/plugins/` directory or install via the WordPress Plugins screen.
2. Activate the plugin through the Plugins screen in WordPress.
3. Go to **WooCommerce > Settings > Payments** and enable the coins you want.
4. Enter your wallet addresses where prompted and save.

== Frequently Asked Questions ==
= Does it support WooCommerce checkout blocks? =
Yes. Block assets are enqueued and compatibility is declared for the Checkout block.

= Are updates disabled? =
Yes. The plugin header includes a custom `Update URI` and filters remove this plugin from update checks and auto-updates.

= Do I need third-party accounts? =
No custodial accounts or KYC are required; payments go directly to the wallet addresses you provide.

== Changelog ==
= 1.1.4 =
* Declare compatibility with WooCommerce custom order tables and cart/checkout blocks.
* Add checkout block assets and styling enqueue.
* Disable plugin update checks and auto-updates.
* Include multiple chain-specific gateways (BTC, ETH, ERC20/BEP20/TRC20 tokens, Arbitrum, Polygon, Avalanche, Base, Optimism, Solana, Monad, Linea, and more).

== Upgrade Notice ==
= 1.1.4 =
Updates are disabled for this plugin; no action needed.
